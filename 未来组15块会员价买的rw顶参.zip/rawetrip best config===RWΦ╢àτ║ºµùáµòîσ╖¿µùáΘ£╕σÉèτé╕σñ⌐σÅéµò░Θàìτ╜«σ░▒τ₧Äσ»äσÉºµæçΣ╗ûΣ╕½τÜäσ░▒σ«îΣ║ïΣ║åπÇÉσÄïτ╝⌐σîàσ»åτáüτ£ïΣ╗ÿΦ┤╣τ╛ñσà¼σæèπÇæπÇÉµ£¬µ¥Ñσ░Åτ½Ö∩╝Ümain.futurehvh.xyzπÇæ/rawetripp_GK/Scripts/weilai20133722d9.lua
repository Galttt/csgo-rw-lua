cheat.notify("resolver by To1m#0922")
cheat.notify("this is just spam resolver types which improves the resolver a little")
cheat.notify("works like a legbreaker")

ui.add_checkbox("Enable resolver")

local swtich = true

local function Resospam()
    local local_player = entitylist.get_local_player()
    local is_alive = local_player:is_alive()
    if ui.get_bool("Enable resolver") == true then
        if is_alive == true then
            if swtich then
                swtich = false
            else
                swtich = true
            end
            if swtich then
                ui.set_int("Ragebot.resolvertypes", 0)
            else
                ui.set_int("Ragebot.resolvertypes", 1)
            end
        else
            ui.set_int("Ragebot.resolvertypes", 1)
        end  
    end
end
cheat.RegisterCallback("on_createmove", Resospam)

local randomz

events.register_event("player_death", function(e)
    local attacker = e:get_int("attacker")
    local attacker_to_player = engine.get_player_for_user_id(attacker)
    
    local lp_idx = engine.get_local_player_index()
    
    if attacker_to_player == lp_idx then
     phrases = {"☞【❤未来组RW公开❤】你被未来组的RW公开参数拿捏了，火速加群743140331获取更多顶尖参数！群内全部类型参数应有尽有！每日免费更新顶参 永久稳定包更新！欢迎进群！",
                 "☞【❤未来组RW公开❤】你被未来组的RW公开参数拿捏了，火速加群743140331获取更多顶尖参数！群内全部类型参数应有尽有！每日免费更新顶参 永久稳定包更新！欢迎进群！",
                 "☞【❤未来组RW公开❤】你被未来组的RW公开参数拿捏了，火速加群743140331获取更多顶尖参数！群内全部类型参数应有尽有！每日免费更新顶参 永久稳定包更新！欢迎进群！",
                 "☞【❤未来组RW公开❤】你被未来组的RW公开参数拿捏了，火速加群743140331获取更多顶尖参数！群内全部类型参数应有尽有！每日免费更新顶参 永久稳定包更新！欢迎进群！",
                 "☞【❤未来组RW公开❤】你被未来组的RW公开参数拿捏了，火速加群743140331获取更多顶尖参数！群内全部类型参数应有尽有！每日免费更新顶参 永久稳定包更新！欢迎进群！",
                 "☞【❤未来组RW公开❤】你被未来组的RW公开参数拿捏了，火速加群743140331获取更多顶尖参数！群内全部类型参数应有尽有！每日免费更新顶参 永久稳定包更新！欢迎进群！",
                 "☞【❤未来组RW公开❤】你被未来组的RW公开参数拿捏了，火速加群743140331获取更多顶尖参数！群内全部类型参数应有尽有！每日免费更新顶参 永久稳定包更新！欢迎进群！",
                 "☞【❤未来组RW公开❤】你被未来组的RW公开参数拿捏了，火速加群743140331获取更多顶尖参数！群内全部类型参数应有尽有！每日免费更新顶参 永久稳定包更新！欢迎进群！"}
            randomz = math.random(1,8)
        console.execute_client_cmd("say " .. phrases[randomz])
    end
end)