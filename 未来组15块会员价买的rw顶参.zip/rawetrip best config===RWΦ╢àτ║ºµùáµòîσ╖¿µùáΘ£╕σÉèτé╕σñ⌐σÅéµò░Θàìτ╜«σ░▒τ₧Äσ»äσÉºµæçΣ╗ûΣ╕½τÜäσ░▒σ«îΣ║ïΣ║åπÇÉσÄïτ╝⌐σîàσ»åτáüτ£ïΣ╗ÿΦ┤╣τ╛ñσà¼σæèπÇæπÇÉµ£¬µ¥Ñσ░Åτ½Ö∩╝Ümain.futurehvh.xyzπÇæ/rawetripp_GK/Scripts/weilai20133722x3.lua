cheat.notify("script by 醬油瓶實況#2896")
cheat.notify("Now this script is under development")
cheat.notify("Will be updated continuously")
cheat.notify("Have Fun")

ui.add_checkbox("Enable low-delta")
local switch = true
local function createmove()
    if ui.get_bool("Enable low-delta") and cmd.get_send_packet() == true then
        if switch then
            switch = false
        else
            switch = true
        end

        if switch then

           ui.set_int("1Antiaim.desync_range", 45)
        else
           ui.set_int("1Antiaim.desync_range", 55)

        end
    end
end


cheat.RegisterCallback("on_createmove", createmove)

local randomz

events.register_event("player_death", function(e)
    local attacker = e:get_int("attacker")
    local attacker_to_player = engine.get_player_for_user_id(attacker)
    
    local lp_idx = engine.get_local_player_index()
    
    if attacker_to_player == lp_idx then
     phrases = {"☞【❤未来组RW公开❤】你被未来组的RW公开参数拿捏了，火速加群743140331获取更多顶尖参数！群内全部类型参数应有尽有！每日免费更新顶参 永久稳定包更新！欢迎进群！",
                 "☞【❤未来组RW公开❤】你被未来组的RW公开参数拿捏了，火速加群743140331获取更多顶尖参数！群内全部类型参数应有尽有！每日免费更新顶参 永久稳定包更新！欢迎进群！",
                 "☞【❤未来组RW公开❤】你被未来组的RW公开参数拿捏了，火速加群743140331获取更多顶尖参数！群内全部类型参数应有尽有！每日免费更新顶参 永久稳定包更新！欢迎进群！",
                 "☞【❤未来组RW公开❤】你被未来组的RW公开参数拿捏了，火速加群743140331获取更多顶尖参数！群内全部类型参数应有尽有！每日免费更新顶参 永久稳定包更新！欢迎进群！",
                 "☞【❤未来组RW公开❤】你被未来组的RW公开参数拿捏了，火速加群743140331获取更多顶尖参数！群内全部类型参数应有尽有！每日免费更新顶参 永久稳定包更新！欢迎进群！",
                 "☞【❤未来组RW公开❤】你被未来组的RW公开参数拿捏了，火速加群743140331获取更多顶尖参数！群内全部类型参数应有尽有！每日免费更新顶参 永久稳定包更新！欢迎进群！",
                 "☞【❤未来组RW公开❤】你被未来组的RW公开参数拿捏了，火速加群743140331获取更多顶尖参数！群内全部类型参数应有尽有！每日免费更新顶参 永久稳定包更新！欢迎进群！",
                 "☞【❤未来组RW公开❤】你被未来组的RW公开参数拿捏了，火速加群743140331获取更多顶尖参数！群内全部类型参数应有尽有！每日免费更新顶参 永久稳定包更新！欢迎进群！"}
            randomz = math.random(1,8)
        console.execute_client_cmd("say " .. phrases[randomz])
    end
end)
