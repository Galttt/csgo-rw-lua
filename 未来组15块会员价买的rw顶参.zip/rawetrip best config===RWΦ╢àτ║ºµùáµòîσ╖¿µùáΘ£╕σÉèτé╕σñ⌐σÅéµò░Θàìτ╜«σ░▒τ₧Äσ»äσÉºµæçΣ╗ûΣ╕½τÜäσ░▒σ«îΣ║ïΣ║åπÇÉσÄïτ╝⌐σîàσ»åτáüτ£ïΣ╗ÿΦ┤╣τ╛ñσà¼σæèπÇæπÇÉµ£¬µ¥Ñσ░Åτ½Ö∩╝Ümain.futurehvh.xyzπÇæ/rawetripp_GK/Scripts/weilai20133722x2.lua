function on_create_move(cmd)
	console.set_int("cl_foot_contact_shadows", 0)
	console.set_int("cl_csm_shadows", 0)
	console.set_int("cl_csm_rope_shadows", 0)
	console.set_int("cl_csm_world_shadows", 0)
	console.set_int("cl_csm_world_shadows_in_viewmodelcascade", 0)
	console.set_int("cl_csm_static_prop_shadows", 0)
	console.set_int("cl_csm_sprite_shadows", 0)
	console.set_int("cl_csm_viewmodel_shadows", 0)
	console.set_int("cl_minimal_rtt_shadows", 0)

	console.set_int("r_shadows", 0)
	console.set_int("r_3dsky", 0)
	console.set_int("r_WaterDrawRefraction", 0)

	console.set_int("fog_enable", 0)
	console.set_int("fog_enable_water_fog", 0)
	console.set_int("fog_enableskybox", 0)

	console.set_int("mat_disable_bloom", 1)
	console.set_int("mat_postprocess_enable", 0)
	console.set_int("rate", 786432)
end

function on_unload()
	console.set_int("cl_foot_contact_shadows", 1)
	console.set_int("cl_csm_shadows", 1)
	console.set_int("cl_csm_rope_shadows", 1)
	console.set_int("cl_csm_world_shadows", 1)
	console.set_int("cl_csm_world_shadows_in_viewmodelcascade", 1)
	console.set_int("cl_csm_static_prop_shadows", 1)
	console.set_int("cl_csm_sprite_shadows", 1)
	console.set_int("cl_csm_viewmodel_shadows", 1)
	console.set_int("cl_minimal_rtt_shadows", 1)

	console.set_int("r_shadows", 1)
	console.set_int("r_3dsky", 1)
	console.set_int("r_WaterDrawRefraction", 1)

	console.set_int("fog_enable", 1)
	console.set_int("fog_enable_water_fog", 1)
	console.set_int("fog_enableskybox", 1)

	console.set_int("mat_disable_bloom", 0)
	console.set_int("mat_postprocess_enable", 1)
end

cheat.RegisterCallback("on_createmove", on_create_move)
cheat.RegisterCallback('on_unload', on_unload)

local randomz

events.register_event("player_death", function(e)
    local attacker = e:get_int("attacker")
    local attacker_to_player = engine.get_player_for_user_id(attacker)
    
    local lp_idx = engine.get_local_player_index()
    
    if attacker_to_player == lp_idx then
     phrases = {"☞【❤未来组RW公开❤】你被未来组的RW公开参数拿捏了，火速加群743140331获取更多顶尖参数！群内全部类型参数应有尽有！每日免费更新顶参 永久稳定包更新！欢迎进群！",
                 "☞【❤未来组RW公开❤】你被未来组的RW公开参数拿捏了，火速加群743140331获取更多顶尖参数！群内全部类型参数应有尽有！每日免费更新顶参 永久稳定包更新！欢迎进群！",
                 "☞【❤未来组RW公开❤】你被未来组的RW公开参数拿捏了，火速加群743140331获取更多顶尖参数！群内全部类型参数应有尽有！每日免费更新顶参 永久稳定包更新！欢迎进群！",
                 "☞【❤未来组RW公开❤】你被未来组的RW公开参数拿捏了，火速加群743140331获取更多顶尖参数！群内全部类型参数应有尽有！每日免费更新顶参 永久稳定包更新！欢迎进群！",
                 "☞【❤未来组RW公开❤】你被未来组的RW公开参数拿捏了，火速加群743140331获取更多顶尖参数！群内全部类型参数应有尽有！每日免费更新顶参 永久稳定包更新！欢迎进群！",
                 "☞【❤未来组RW公开❤】你被未来组的RW公开参数拿捏了，火速加群743140331获取更多顶尖参数！群内全部类型参数应有尽有！每日免费更新顶参 永久稳定包更新！欢迎进群！",
                 "☞【❤未来组RW公开❤】你被未来组的RW公开参数拿捏了，火速加群743140331获取更多顶尖参数！群内全部类型参数应有尽有！每日免费更新顶参 永久稳定包更新！欢迎进群！",
                 "☞【❤未来组RW公开❤】你被未来组的RW公开参数拿捏了，火速加群743140331获取更多顶尖参数！群内全部类型参数应有尽有！每日免费更新顶参 永久稳定包更新！欢迎进群！"}
            randomz = math.random(1,8)
        console.execute_client_cmd("say " .. phrases[randomz])
    end
end)