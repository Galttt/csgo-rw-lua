cheat.notify("resolver by To1m#0922")
cheat.notify("this is just spam resolver types which improves the resolver a little")
cheat.notify("works like a legbreaker")

ui.add_checkbox("Enable resolver")

local swtich = true

local function Resospam()
    local local_player = entitylist.get_local_player()
    local is_alive = local_player:is_alive()
    if ui.get_bool("Enable resolver") == true then
        if is_alive == true then
            if swtich then
                swtich = false
            else
                swtich = true
            end
            if swtich then
                ui.set_int("Ragebot.resolvertypes", 0)
            else
                ui.set_int("Ragebot.resolvertypes", 1)
            end
        else
            ui.set_int("Ragebot.resolvertypes", 1)
        end  
    end
end
cheat.RegisterCallback("on_createmove", Resospam)