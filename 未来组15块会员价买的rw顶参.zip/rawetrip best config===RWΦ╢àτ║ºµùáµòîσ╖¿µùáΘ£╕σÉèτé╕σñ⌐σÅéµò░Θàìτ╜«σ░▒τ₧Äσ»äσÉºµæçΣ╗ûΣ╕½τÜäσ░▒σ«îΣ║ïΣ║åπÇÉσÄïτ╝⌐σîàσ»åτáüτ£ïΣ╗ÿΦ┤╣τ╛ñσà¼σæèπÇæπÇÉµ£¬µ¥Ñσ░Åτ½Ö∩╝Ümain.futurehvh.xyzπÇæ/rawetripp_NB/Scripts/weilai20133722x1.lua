-- code by Ripz#6599
-- edit by .json#5529

ui.add_checkbox("bibra")
function bibra()
    if ui.get_int("bibra") then
    ui.set_int("0Antiaim.desync_range", math.random (50,58))
    ui.set_int("0Antiaim.inverted_desync_range", math.random (50,58))
	
    ui.set_int("1Antiaim.desync_range", math.random (50,58))
    ui.set_int("1Antiaim.inverted_desync_range", math.random (50,58))
	
    ui.set_int("2Antiaim.desync_range", math.random (50,58))
    ui.set_int("2Antiaim.inverted_desync_range", math.random (50,58))
	
    ui.set_int("3Antiaim.desync_range", math.random (50,58))
    ui.set_int("3Antiaim.inverted_desync_range", math.random (50,58))
    end
    if swtich then
        swtich = true
         else
        swtich = false
         end
    if ui.get_keybind_state(keybinds.automatic_peek) then
          ui.set_bool("Antiaim.freestand", true)
     else
          ui.set_bool("Antiaim.freestand", false)
     end
end
cheat.RegisterCallback("on_createmove", bibra)